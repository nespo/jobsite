

// GLightbox Popup

var lightbox = GLightbox({
    selector: '.image-popup'
  });