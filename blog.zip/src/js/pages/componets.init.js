var spy = new Gumshoe('#elementsBar a',{
    offset:90
});


// Smooth scroll 
var scroll = new SmoothScroll('#elementsBar a', {
    speed: 1000,
    offset: 90
});