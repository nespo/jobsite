
var singleFilter = new Choices('#choices-single-filter-orderby');

var singleCandidate = new Choices('#choices-candidate-page');