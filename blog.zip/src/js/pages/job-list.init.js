var singleLocation = new Choices('#choices-single-location');

var singleCategorie = document.getElementById('choices-single-categories');
if(singleCategorie){
    var singleCategories = new Choices('#choices-single-categories');
}
    

