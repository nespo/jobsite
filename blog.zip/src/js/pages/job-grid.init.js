var textRemove = new Choices(
    document.getElementById('choices-text-remove-button'),
        {
        delimiter: ',',
        editItems: true,
        maxItemCount: 5,
        removeItemButton: true,
        }
    );